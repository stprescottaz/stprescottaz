### v0.1.1

- Add Sina Weibo Like Button using AddThis.
- Add Linkedin Share Button using AddThis.

----------------------------------------------------------------
@2014/10/20 HZ


### v0.1.0

- First release of hexo-theme-air.

----------------------------------------------------------------
@2014/10/16 HZ